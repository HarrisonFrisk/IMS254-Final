As this deadline approaches it seems I encounter more and more bugs, that are more and more game-breaking and
at  this point it may seem that regretfully, I will not be able to officially complete this assignment. 
The one thing I am missing is my ability to get the towers to actually be placed, and then work. For whatever
reason there is a very strange issue with my sprites not matching up properly. For instance when I change a 
sprite to "icon_fl" it changes to "btn_start"??? why on earth would that happen...usually when I encounter bugs,
I'm able to troublshoot through them, but I am sincerely struggling to fix this one- and it just so happens to 
completely break the game.

This project however, still shows merit. The "enemies" system works perfectly as intended. I was able to
troubleshoot through numerous bugs, ranging from change room functions not working, draw function errors,
sprites not appearing, to half of my sprite files repeatedly disapearing (that last one not being a bug,
but Gamemaker torturing me). All in all I put a serious amount of effort into this code, and its very 
dissapointing that at the end of it all, I cannot complete it. 


As is the beauty of coding- we learn by failing.